from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, HttpResponse

def community(request):
    return HttpResponse("Welcome to community")

def community(request):
    return render(request, "community.html")

def blog(request):
    return HttpResponse("Welcome to blog")

def blog(request):
    return render(request, "blog.html")
